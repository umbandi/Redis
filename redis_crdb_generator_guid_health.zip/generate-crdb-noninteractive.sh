#!/bin/bash

# Load all required variables from a non-interactive file
source input.conf

# Constants and files
CONFIG_JSON="crdb_config.json"
LOG_FILE="crdb_creation.log"
DBNAME="${APP_NAME}-${SUB_APP}-${ENV,,}-crdb-${DB_SEQ}"
MEMORY_BYTES=$((MEMORY_GB * 1024 * 1024 * 1024))
SLACK_WEBHOOK_URL="https://hooks.slack.com/services/T00000000/B00000000/XXXXXXXXXXXXXXXXXXXXXXXX"

# Redis Enterprise credentials and cert (update accordingly)
RE_USERNAME="admin@company.com"
RE_PASSWORD="yourpassword"
BASE64_PEM_CERT="-----BEGIN CERTIFICATE-----\n...\n-----END CERTIFICATE-----"

timestamp() { date +"%Y-%m-%d %H:%M:%S"; }

log() {
  echo "$(timestamp) - $1" | tee -a "$LOG_FILE"
}

log "Starting CRDB validation and creation for $DBNAME"

# Load clusters
mapfile -t CLUSTERS < clusters.txt
TOTAL=${#CLUSTERS[@]}
MAX_CLUSTERS=5

if [[ $TOTAL -eq 0 ]]; then
  log "✘ No clusters listed in clusters.txt"
  exit 1
elif (( $TOTAL > $MAX_CLUSTERS )); then
  log "✘ Too many clusters listed. Max allowed: $MAX_CLUSTERS. Found: $TOTAL"
  exit 1
fi

# DB name uniqueness check
for cluster in "${CLUSTERS[@]}"; do
  CLUSTER_NAME=$(echo "$cluster" | awk '{print $1}')
  CLUSTER_URL=$(echo "$cluster" | awk '{print $2}')
  EXISTING=$(curl -sk -u ${RE_USERNAME}:${RE_PASSWORD} https://${CLUSTER_URL}:9443/v1/bdbs | jq -r '.[].name' | grep -w "$DBNAME")

  if [[ -z "$EXISTING" ]]; then
    log "✔ DB name $DBNAME is unique on $CLUSTER_NAME"
  else
    log "✘ DB name $DBNAME already exists on $CLUSTER_NAME. Change the sequence number."
    exit 1
  fi
done

# Build CRDB JSON
echo "[" > "$CONFIG_JSON"
i=0
for cluster in "${CLUSTERS[@]}"; do
  CLUSTER_NAME=$(echo "$cluster" | awk '{print $1}')
  CLUSTER_URL=$(echo "$cluster" | awk '{print $2}')

  cat <<EOL >> "$CONFIG_JSON"
{
  "cluster": {
    "url": "https://${CLUSTER_URL}:9443",
    "credentials": {
      "username": "${RE_USERNAME}",
      "password": "${RE_PASSWORD}"
    },
    "name": "${CLUSTER_NAME}"
  },
  "db_config": {
    "tls_mode": "enabled",
    "enforce_client_authentication": "enabled",
    "client_cert_subject_validation_type": "full_subject",
    "authorized_subjects": [{
      "C": "US",
      "CN": "${CN}",
      "O": "Wells Fargo",
      "OU": ["${OU}"]
    }],
    "authentication_ssl_client_certs": [{
      "client_cert": "${BASE64_PEM_CERT}"
    }],
    "compression": 6
  }
}$( [[ $i -lt $((TOTAL - 1)) ]] && echo "," )
EOL

  ((i++))
done
echo "]" >> "$CONFIG_JSON"
log "✔ Generated CRDB JSON: $CONFIG_JSON"

# Validate JSON
if command -v jq &>/dev/null && jq . "$CONFIG_JSON" > /dev/null; then
  log "✔ JSON validation passed"
else
  log "✘ JSON validation failed"
  exit 1
fi

# Submit CRDB
CLUSTER_URL=$(echo "${CLUSTERS[0]}" | awk '{print $2}')
ACCESS_TOKEN=$(curl -sk -X POST "https://${CLUSTER_URL}:9443/v1/login"   -H "Content-Type: application/json"   -d "{"username":"${RE_USERNAME}","password":"${RE_PASSWORD}"}" | jq -r .access_token)

if [[ "$ACCESS_TOKEN" == "null" || -z "$ACCESS_TOKEN" ]]; then
  log "✘ Failed to authenticate to Redis Enterprise"
  curl -s -X POST -H 'Content-type: application/json' --data "{"text":"❌ Auth failure for ${DBNAME}"}" "$SLACK_WEBHOOK_URL"
  exit 1
fi

log "✔ Authenticated. Submitting CRDB creation..."
RESPONSE=$(curl -sk -X POST "https://${CLUSTER_URL}:9443/v1/crdbs"   -H "Authorization: Bearer $ACCESS_TOKEN"   -H "Content-Type: application/json"   -d @"$CONFIG_JSON")

echo "$RESPONSE" | jq . | tee -a "$LOG_FILE"

if echo "$RESPONSE" | jq -e '.uid' > /dev/null; then
  log "✅ CRDB created: ${DBNAME}"
  curl -s -X POST -H 'Content-type: application/json' --data "{"text":"✅ CRDB created successfully: ${DBNAME}"}" "$SLACK_WEBHOOK_URL"
else
  log "❌ CRDB creation failed for ${DBNAME}"
  curl -s -X POST -H 'Content-type: application/json' --data "{"text":"❌ CRDB creation failed for ${DBNAME}"}" "$SLACK_WEBHOOK_URL"
  exit 1
fi
