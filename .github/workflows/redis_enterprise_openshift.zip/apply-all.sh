#!/bin/bash
oc apply -f redis-enterprise-cluster.yaml
oc apply -f redis-database.yaml
