#!/bin/bash
oc new-project redis-enterprise
