#!/bin/bash

INPUT_JSON="input.json"
CLUSTER_URL="https://your-cluster-url:9443"
LOG_FILE="crdb_creation.log"
SLACK_WEBHOOK_URL="https://hooks.slack.com/services/T00000000/B00000000/XXXXXXXXXXXXXXXXXXXXXXXX"

timestamp() { date +"%Y-%m-%d %H:%M:%S"; }

log() {
  echo "$(timestamp) - $1" | tee -a "$LOG_FILE"
}

slack_notify() {
  curl -s -X POST -H 'Content-type: application/json' \
    --data "{"text":"$1"}" "$SLACK_WEBHOOK_URL" > /dev/null
}

# Ensure input.json exists
if [[ ! -f "$INPUT_JSON" ]]; then
  log "❌ input.json not found"
  slack_notify "❌ CRDB submission failed: input.json not found"
  exit 1
fi

log "📥 Loading input.json..."
USERNAME=$(jq -r '.USERNAME' "$INPUT_JSON")
PASSWORD=$(jq -r '.PASSWORD' "$INPUT_JSON")
ENV=$(jq -r '.ENV' "$INPUT_JSON")

if [[ -z "$USERNAME" || -z "$PASSWORD" || -z "$ENV" ]]; then
  log "❌ Required fields missing from input.json"
  slack_notify "❌ Required fields missing in CRDB input.json"
  exit 1
fi

log "🌐 Authenticating with Redis Enterprise cluster at $CLUSTER_URL"
ACCESS_TOKEN=$(curl -sk -X POST "${CLUSTER_URL}/v1/login" \
  -H "Content-Type: application/json" \
  -d '{"username": "'"$USERNAME"'", "password": "'"$PASSWORD"'"}' | jq -r .access_token)

if [[ -z "$ACCESS_TOKEN" || "$ACCESS_TOKEN" == "null" ]]; then
  log "❌ Authentication failed"
  slack_notify "❌ CRDB authentication failed for $ENV environment"
  exit 1
fi

log "🔑 Authenticated. Submitting CRDB for $ENV environment..."
RESPONSE=$(curl -sk -X POST "${CLUSTER_URL}/v1/crdbs" \
  -H "Authorization: Bearer $ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  -d @"$INPUT_JSON")

log "📤 CRDB submission response:"
echo "$RESPONSE" | jq . | tee -a "$LOG_FILE"

if echo "$RESPONSE" | jq -e '.task_id' > /dev/null; then
  TASK_ID=$(echo "$RESPONSE" | jq -r '.task_id')
  log "🕐 CRDB task started successfully: Task ID = $TASK_ID"
  slack_notify "✅ CRDB creation started in $ENV environment. Task ID: $TASK_ID"
else
  log "❌ CRDB creation failed"
  slack_notify "❌ CRDB creation failed in $ENV environment"
  exit 1
fi

# Optional: poll for GUID
log "🔁 Polling for CRDB GUID..."
for attempt in {1..10}; do
  GUID=$(curl -sk -H "Authorization: Bearer $ACCESS_TOKEN" \
    -X GET "${CLUSTER_URL}/v1/crdb_tasks/${TASK_ID}" | jq -r '.crdb_guid')
  [[ "$GUID" != "null" && -n "$GUID" ]] && break
  sleep 5
done

if [[ -z "$GUID" || "$GUID" == "null" ]]; then
  log "❌ Failed to retrieve CRDB GUID"
  slack_notify "⚠️ CRDB creation started but GUID could not be retrieved"
  exit 1
fi

log "✅ CRDB GUID: $GUID"
slack_notify "✅ CRDB created successfully with GUID: $GUID in $ENV"
