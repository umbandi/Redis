#!/bin/bash

# Load input variables
source input.conf

LOG_FILE="crdb_creation.log"
CONFIG_JSON="crdb_config.json"
DBNAME="${APP_NAME}-${SUB_APP}-${ENV,,}-crdb-${DB_SEQ}"
MEMORY_BYTES=$((MEMORY_GB * 1024 * 1024 * 1024))

# Redis credentials and cert
RE_USERNAME="admin@company.com"
RE_PASSWORD="yourpassword"
BASE64_PEM_CERT="-----BEGIN CERTIFICATE-----\n...\n-----END CERTIFICATE-----"

# Slack webhook for alerting (optional)
SLACK_WEBHOOK_URL="https://hooks.slack.com/services/T00000000/B00000000/XXXXXXXXXXXXXXXXXXXXXXXX"

# Normalize toggle values
SHARD_BOOL=$( [[ "${USE_SHARDING,,}" == "yes" || "${USE_SHARDING,,}" == "true" ]] && echo true || echo false )
OSS_API_BOOL=$( [[ "${USE_OSS_API,,}" == "yes" || "${USE_OSS_API,,}" == "true" ]] && echo true || echo false )

# Timestamp prefix for logs
timestamp() { date +"%Y-%m-%d %H:%M:%S"; }

log() {
  echo "$(timestamp) - $1" | tee -a "$LOG_FILE"
}

log "Starting CRDB creation for $DBNAME"

# Read cluster info
mapfile -t CLUSTERS < <(cat clusters.txt)

echo "[" > $CONFIG_JSON

i=0
for cluster in "${CLUSTERS[@]}"; do
  CLUSTER_NAME=$(echo $cluster | awk '{print $1}')
  CLUSTER_URL=$(echo $cluster | awk '{print $2}')

  cat <<EOL >> $CONFIG_JSON
{
  "cluster": {
    "url": "https://${CLUSTER_URL}:9443",
    "credentials": {
      "username": "${RE_USERNAME}",
      "password": "${RE_PASSWORD}"
    },
    "name": "${CLUSTER_NAME}"
  },
  "db_config": {
    "tls_mode": "enabled",
    "enforce_client_authentication": "enabled",
    "client_cert_subject_validation_type": "full_subject",
    "authorized_subjects": [{
      "C": "US",
      "CN": "$CN",
      "O": "Wells Fargo",
      "OU": ["$OU"]
    }],
    "authentication_ssl_client_certs": [{
      "client_cert": "${BASE64_PEM_CERT}"
    }],
    "compression": 6,
    "sharding": ${SHARD_BOOL},
    "oss_cluster_api": ${OSS_API_BOOL}
  }
}$( [[ $i -lt $((NUM_CLUSTERS - 1)) ]] && echo "," )
EOL

  ((i++))
done

echo "]" >> $CONFIG_JSON

if command -v jq &>/dev/null; then
  if jq . "$CONFIG_JSON" > /dev/null; then
    log "✔ Valid JSON"
  else
    log "✘ Invalid JSON"
    exit 1
  fi
else
  log "⚠ jq not installed, skipping validation"
fi

if [[ "$1" == "--dry-run" ]]; then
  log "Dry-run mode enabled. JSON not submitted."
  exit 0
fi

CLUSTER_URL=$(echo ${CLUSTERS[0]} | awk '{print $2}')
ACCESS_TOKEN=$(curl -sk -X POST "https://${CLUSTER_URL}:9443/v1/login" \
  -H "Content-Type: application/json" \
  -d "{"username":"${RE_USERNAME}","password":"${RE_PASSWORD}"}" | jq -r .access_token)

if [[ "$ACCESS_TOKEN" == "null" || -z "$ACCESS_TOKEN" ]]; then
  log "✘ Login failed. Check credentials."
  curl -s -X POST -H 'Content-type: application/json' \
    --data "{"text":"❌ CRDB creation failed during authentication for ${DBNAME}."}" \
    "$SLACK_WEBHOOK_URL"
  exit 1
fi

log "✔ Authenticated. Submitting CRDB request..."
RESPONSE=$(curl -sk -X POST "https://${CLUSTER_URL}:9443/v1/crdbs" \
  -H "Authorization: Bearer $ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  -d @"$CONFIG_JSON")

echo "$RESPONSE" | jq . | tee -a "$LOG_FILE"

if echo "$RESPONSE" | jq -e '.uid' > /dev/null; then
  log "✅ CRDB created successfully: $DBNAME"
  curl -s -X POST -H 'Content-type: application/json' \
    --data "{"text":"✅ CRDB created successfully: ${DBNAME}"}" \
    "$SLACK_WEBHOOK_URL"
else
  log "❌ CRDB creation failed: $DBNAME"
  curl -s -X POST -H 'Content-type: application/json' \
    --data "{"text":"❌ CRDB creation failed for ${DBNAME}. Check logs or JSON config."}" \
    "$SLACK_WEBHOOK_URL"
fi
