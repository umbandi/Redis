#!/bin/bash

# Non-interactive version: load variables from configuration file
source input.conf

CA_CERT_PATH="/etc/ssl/certs/redislabs-root-ca-cert-CHAIN.pem"

# Validate clusters.txt file
CLUSTER_FILE="clusters.txt"
if [[ ! -f "$CLUSTER_FILE" ]]; then
  echo "❌ Cluster input file '$CLUSTER_FILE' not found."
  exit 1
fi

CLUSTERS=($(cat "$CLUSTER_FILE"))
TOTAL=${#CLUSTERS[@]}
MAX_CLUSTERS=5

if (( TOTAL == 0 )); then
  echo "❌ No clusters found in $CLUSTER_FILE"
  exit 1
elif (( TOTAL > MAX_CLUSTERS )); then
  echo "❌ Too many clusters. Max allowed is $MAX_CLUSTERS. Found: $TOTAL"
  exit 1
fi

# Check uniqueness of DB name
DBNAME="${APP_NAME}-${SUB_APP_ID}-${ENV,,}-crdb-${SEQ_NO}"

for CLUS in "${CLUSTERS[@]}"; do
  EXISTING=$(curl -sk -u "${USERNAME}:${PASSWORD}" https://${CLUS}:9443/v1/bdbs | jq -r '.[].name' | grep -w "$DBNAME" | uniq)
  if [[ -z "$EXISTING" ]]; then
    echo "✔️ DB name $DBNAME is unique on $CLUS"
  else
    echo "❌ DB name $DBNAME already exists on $CLUS. Please change the sequence number."
    exit 1
  fi
done

CONFIG_JSON="crdb_config.json"
echo "[" > "$CONFIG_JSON"

for (( i=0; i<${#CLUSTERS[@]}; i++ )); do
  CLUSTER_URL="${CLUSTERS[$i]}"
  cat <<EOL >> "$CONFIG_JSON"
{
  "cluster": {
    "url": "https://${CLUSTER_URL}:9443",
    "credentials": {
      "username": "${USERNAME}",
      "password": "${PASSWORD}"
    },
    "name": "${CLUSTER_URL}"
  },
  "db_config": {
    "tls_mode": "enabled",
    "enforce_client_authentication": "enabled",
    "client_cert_subject_validation_type": "full_subject",
    "authorized_subjects": [{
      "C": "US",
      "CN": "${CN}",
      "O": "Wells Fargo",
      "OU": ["${OU}"]
    }],
    "authentication_ssl_client_certs": [{
      "client_cert": "${CA_CERT_PATH}"
    }],
    "compression": 6
  }
}$( [[ $i -lt $((TOTAL-1)) ]] && echo "," )
EOL
done

echo "]" >> "$CONFIG_JSON"

# Validate JSON
if command -v jq &> /dev/null; then
  jq . "$CONFIG_JSON" > /dev/null && echo "✔ Valid JSON: $CONFIG_JSON" || { echo "❌ JSON validation failed!"; exit 1; }
else
  echo "⚠ jq not installed. Skipping validation."
fi
