#!/bin/bash

# Load input configuration
source input.conf

CONFIG_JSON="crdb_config.json"
LOG_FILE="crdb_creation.log"
DBNAME="${APP_NAME}-${SUB_APP}-${ENV,,}-crdb-${DB_SEQ}"
MEMORY_BYTES=$((MEMORY_GB * 1024 * 1024 * 1024))
SLACK_WEBHOOK_URL="https://hooks.slack.com/services/T00000000/B00000000/XXXXXXXXXXXXXXXXXXXXXXXX"

RE_USERNAME="admin@company.com"
RE_PASSWORD="yourpassword"
BASE64_PEM_CERT="-----BEGIN CERTIFICATE-----\n...\n-----END CERTIFICATE-----"

timestamp() { date +"%Y-%m-%d %H:%M:%S"; }

log() {
  echo "$(timestamp) - $1" | tee -a "$LOG_FILE"
}

log "🔁 Starting Redis CRDB creation process for $DBNAME"

# Read cluster definitions
mapfile -t CLUSTERS < clusters.txt

# Check DB name uniqueness
for cluster in "${CLUSTERS[@]}"; do
  CLUSTER_NAME=$(echo "$cluster" | awk '{print $1}')
  CLUSTER_URL=$(echo "$cluster" | awk '{print $2}')
  EXISTING=$(curl -sk -u ${RE_USERNAME}:${RE_PASSWORD} https://${CLUSTER_URL}:9443/v1/bdbs | jq -r '.[].name' | grep -w "$DBNAME")

  if [[ -n "$EXISTING" ]]; then
    log "❌ DB name $DBNAME already exists on $CLUSTER_NAME. Please change the sequence number."
    exit 1
  else
    log "✔ DB name $DBNAME is unique on $CLUSTER_NAME"
  fi
done

# Generate JSON
echo "[" > "$CONFIG_JSON"
i=0
for cluster in "${CLUSTERS[@]}"; do
  CLUSTER_NAME=$(echo "$cluster" | awk '{print $1}')
  CLUSTER_URL=$(echo "$cluster" | awk '{print $2}')

  cat <<EOL >> "$CONFIG_JSON"
{
  "cluster": {
    "url": "https://${CLUSTER_URL}:9443",
    "credentials": {
      "username": "${RE_USERNAME}",
      "password": "${RE_PASSWORD}"
    },
    "name": "${CLUSTER_NAME}"
  },
  "db_config": {
    "tls_mode": "enabled",
    "enforce_client_authentication": "enabled",
    "client_cert_subject_validation_type": "full_subject",
    "authorized_subjects": [{
      "C": "US",
      "CN": "${CN}",
      "O": "Wells Fargo",
      "OU": ["${OU}"]
    }],
    "authentication_ssl_client_certs": [{
      "client_cert": "${BASE64_PEM_CERT}"
    }],
    "compression": 6
  }
}$( [[ $i -lt $((${#CLUSTERS[@]} - 1)) ]] && echo "," )
EOL
  ((i++))
done
echo "]" >> "$CONFIG_JSON"
log "✔ Generated CRDB JSON config"

# Authenticate
CLUSTER_URL=$(echo "${CLUSTERS[0]}" | awk '{print $2}')
ACCESS_TOKEN=$(curl -sk -X POST "https://${CLUSTER_URL}:9443/v1/login"   -H "Content-Type: application/json"   -d "{"username":"${RE_USERNAME}","password":"${RE_PASSWORD}"}" | jq -r .access_token)

if [[ -z "$ACCESS_TOKEN" || "$ACCESS_TOKEN" == "null" ]]; then
  log "❌ Failed to authenticate"
  exit 1
fi

log "✔ Authenticated successfully. Submitting CRDB creation..."

# Submit CRDB creation
TASKID=$(curl -sk -H "Authorization: Bearer ${ACCESS_TOKEN}"   -H "Content-Type: application/json"   -d @"$CONFIG_JSON"   -X POST "https://${CLUSTER_URL}:9443/v1/crdbs" | jq -r '.task_id')

if [[ -z "$TASKID" || "$TASKID" == "null" ]]; then
  log "❌ Failed to create CRDB. No task ID returned."
  exit 1
fi

log "✔ Task submitted. TASK ID: $TASKID"

# Wait and get GUID
sleep 10
GUID=""
for attempt in {1..10}; do
  GUID=$(curl -sk -H "Authorization: Bearer ${ACCESS_TOKEN}"     -X GET "https://${CLUSTER_URL}:9443/v1/crdb_tasks/${TASKID}" | jq -r '.crdb_guid')
  [[ "$GUID" != "null" && -n "$GUID" ]] && break
  sleep 5
done

if [[ -z "$GUID" || "$GUID" == "null" ]]; then
  log "❌ Failed to retrieve CRDB GUID after task completion."
  exit 1
fi

log "✔ CRDB GUID retrieved: $GUID"

# Health check
HEALTH=$(curl -sk -H "Authorization: Bearer ${ACCESS_TOKEN}"   -X GET "https://${CLUSTER_URL}:9443/v1/bdbs/${GUID}" | jq -r '.health')

log "🔍 CRDB Health Status: $HEALTH"

if [[ "$HEALTH" == "active" ]]; then
  log "✅ CRDB $DBNAME is healthy and active"
else
  log "⚠️ CRDB $DBNAME created but not healthy: $HEALTH"
fi
